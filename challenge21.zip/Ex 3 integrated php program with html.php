<html>
		<head>
		<title> integrated php program with html</title>
		</head>
<body>
		<center><h1>Integrated php program</h1></center>
		<center><?php 
		echo"<i>welcome<i><br><br>";
		echo"<u>to</U><br><br>";
		echo"<b>php</b>";
		?><center>
		</body>
		</html>